 <!-- FOOTER -->
        <footer class="site-footer clearfix" itemscope itemtype="https://schema.org/WPFooter">
            <div class="container theme-container">
                <div class="site-main-footer">               
                    <div class="row">
                        <div class="col-md-3 col-sm-6 clearfix">
                            <section class="widget footer-widget widget_text clearfix">
                                <div class="textwidget">
                                    <p class="fsz-25"> <span class="bold-font-3 wht-clr">Advanced Group</span> <span class="thm-clr funky-font">Marketing</span> </p>
                                    <p>The Best place to Shop</p>
                                </div>
                            </section>
                        </div>

                        <div class="col-md-3 col-sm-6 clearfix">
                            <section class="widget footer-widget widget_nav_menu clearfix">
                            <h6 class="widget-title">Useful Links</h6>
                                <ul>
                                    <li class="menu-item"><a href="about.php">About us</a></li>
                                    <li class="menu-item"><a href="index.php">Products</a></li>
									<li class="menu-item"><a href="faq.php">F.A.Q</a></li>
                                    <li class="menu-item"><a href="contact-us.php">Contact Us</a></li>
                                </ul>   
                            </section>
                        </div>

                        <div class="col-md-3 col-sm-6 clearfix">
                            <section id="nav_menu-3" class="widget footer-widget widget_nav_menu clearfix">
                                <h6 class="widget-title">Connect With us</h6>
								<div class="author-info-social">
                                        <a class="goshop-share rcc-google" href="http://google.com/" rel="nofollow" target="_blank">
                                            <i class="fa fa-google-plus"></i>
                                        </a>
                                        <a class="goshop-share rcc-twitter" href="http://twitter.com/" rel="nofollow" target="_blank">
                                            <i class="fa fa-twitter"></i>
                                        </a>
                                        <a class="goshop-share rcc-facebook" href="http://facebook.com/" rel="nofollow" target="_blank">
                                            <i class="fa fa-facebook"></i>
                                        </a>
                                        <a class="goshop-share rcc-linkedin" href="http://linkedin.com/" rel="nofollow" target="_blank">
                                            <i class="fa fa-linkedin"></i>
                                        </a>
                                </div>
                            </section>
                        </div>

                        <div class="col-md-3 col-sm-6 clearfix">
                            <section id="text-6" class="widget footer-widget widget_text clearfix">
                                <h6 class="widget-title">Newsletter</h6>
                                <div class="textwidget">
                                    Subscribe to get free Newsletter Weekly  Updates of latest offers.
                                    <form class="mc4wp-form">
                                        <p>
                                            <label>Email address: </label>
                                            <input type="email" name="EMAIL" placeholder="Your email address" required />
                                        </p>

                                        <p>
                                            <button class="submit"> <i class="fa fa-envelope-o"></i> </button>                                      
                                        </p>
                                    </form>
                                </div>
                            </section>
                        </div>
                    </div>                
                </div>
            </div>

            <div class="subfooter">
                <div class="container theme-container">
                    <div class="row">
                        <div class="col-md-12 col-sm-12">
                            <p class="left">Copyright &copy; <a href="#" class="thm-clr"> Advanced Group Marketing </a>.  All Right Reserved 2016 </p>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- / FOOTER -->